# set of vowels
a={'a':33}
vowels = {'z'}
print(type(a))
# adding 'o'
vowels.add(a)
print('Vowels are:', vowels)

# adding 'a' again
vowels.add('a')
print('Vowels are:', vowels)