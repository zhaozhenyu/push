import numpy as a
import observations as observations

a = arange(60).reshape(3,4,5);
print( a)